#* @use /some
function(){

}

#* @get /get
function() {

}


#* @put /put
function(req, res, forward){
  7
}

#* @post /post
function() {

}

#* @delete /delete
function() {

}

#* @get /test
#* @post /test
function(){

}

#* @head /head
function() {

}

#* @options /options
function(){

}
