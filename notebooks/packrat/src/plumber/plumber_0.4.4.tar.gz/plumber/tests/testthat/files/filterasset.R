#* @filter test
#* @assets ./files/static
function(){

}
