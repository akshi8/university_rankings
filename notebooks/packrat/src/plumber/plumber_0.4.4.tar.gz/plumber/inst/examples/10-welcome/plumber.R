#* @get /
#* @html
function(){
  "<html><body><h1>plumber is alive!</h1></body></html>"
}
