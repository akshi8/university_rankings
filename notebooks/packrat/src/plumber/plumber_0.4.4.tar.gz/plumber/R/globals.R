.globals <- new.env()
.globals$serializers <- list()
.globals$processors <- new.env()
